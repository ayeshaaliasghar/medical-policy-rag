# embed_and_index.py
