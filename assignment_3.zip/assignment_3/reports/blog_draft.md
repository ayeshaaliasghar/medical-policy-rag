# blog draft
